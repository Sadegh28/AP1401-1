# ==================================================
# ------------| Dont Change This Codes |------------
# ==================================================

import json

class Commands:
    def __init__(self):
        self.data_address = "Data.json"
        
    def read_data(self):
        return json.load(open("Data.json","r"))
    
    def append_data(self,newData):
        last_key = int(list(self.read_data().keys())[-1])
        data = self.read_data()
        newData.update({"id":last_key+1})
        data.update({last_key+1 : newData})
        return json.dumps(data)
    
    def update_data(self,newData, id):
        data = self.read_data()
        data[f"{id}"].update(newData)
        return json.dumps(data)

class DB(Commands):
    def create(self,newData):
        data = self.append_data(newData)
        file = open(self.data_address,"w")
        file.write(data)
        return True
    
    def update(self,newData,id):
        if(id is not None):
            data = self.update_data(newData,id)
            file = open(self.data_address,"w")
            file.write(data)
            return True
        return False
        
    def check_login(self,userName,password):
        data = self.read_data()
        for user in data.values():
            if(user["userName"] == userName and user["password"] == password):
                return user
        return False
    
    def check_register(self,userName,email):
        data = self.read_data()
        for user in data.values():
            if(user["userName"] == userName or user["email"] == email):
                return user
        return False
