from Database import DB

class User:
    def __init__(self):
        # Put the appropriate attributes in this method
        self.db = DB()
    
    # -- Define the methods you need in this section (like Login method) --

    def update_info(self, **keyarg):
        # this method is one the methods that you need in your program
        # insert appropriate parameters to check_loign method ,then complete the rest of method body according to the description
        try:
            user_id = self.db.check_login()["id"]
        except :
            user_id = None


# -- Define Web class here --