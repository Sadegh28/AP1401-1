from Database import DB

class User:
    def __init__(self,userName,email,password):
        self.db = DB()
        self.userName = userName
        self.email = email
        self.password = password
        self.is_login = False        
        
    def login(self,web):
        if(self.db.check_login(self.userName,self.password)):
            web.add_online_users(self)
            self.is_login = True
            return f"{self.userName} successfully logged in !"
        else:
            return "userName or password is not correct !"
        
    def logout(self,web):
        if(self.is_login):
            web.remove_online_users(self)
            self.is_login = False
            return f"{self.userName} successfully logged out !"
        else:
            return "this user is not login yet !"
    
    def register(self):
        if(self.db.check_register(self.userName,self.email)):
            return "This user has already registered !"
        if(self.db.create({"userName":self.userName,"password":self.password,"email":self.email})):
            return "Registration was successful !"
        else:
            return "Registration failed !"
        
    def update_info(self, **keyarg):
        try:
            user_id = self.db.check_login(self.userName,self.password)["id"]
        except :
            user_id = None
        if(self.db.update(keyarg,user_id)):
            return "The information has been successfully updated"
        return "The update operation was unsuccessful"



class Web:
    def __init__(self):
        self.online_users_list = []
    def add_online_users(self,user):
        if(user.userName not in self.online_users_list):
            self.online_users_list.append(user.userName)
    def remove_online_users(self,user):
        self.online_users_list.remove(user.userName)

web = Web()
user = User(userName = "kairash" , password = "1234" , email = "kia20.mail@gmail.com")
user2 = User(userName = "koroush" , password = "1234" , email = "koroush@ymail.com")
print(user.login(web))
print(user2.login(web))
print(user.logout(web))

a = User(userName = "kairash" , password = "1234" , email = "kia20.mail@gmail.com")
# print(user)
# print(a.update_info(userName = "majid" , mobile = "0912"))

print(web.online_users_list)